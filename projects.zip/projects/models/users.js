var mongoose=require('mongoose');
const schema=mongoose.Schema;

const UserSchema=new schema(
    {
        username:{type: String},
        email:{type: String},
        password:{type: String},
        confirmPassword:{type: String},
    }
);

const User= mongoose.model('Users',UserSchema);
module.exports=User;