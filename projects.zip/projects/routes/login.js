var express = require('express');
var router = express.Router();
    mongoose = require('mongoose'), //mongo connection
    bodyParser = require('body-parser'), //parses information from POST
    methodOverride = require('method-override'); //used to manipulate POST
    bcrypt= require('bcrypt');
    session=require('express-session');
const User=require('../models/users');
//Any requests to this controller must pass through this 'use' function
//Copy and pasted from method-override
router.use(bodyParser.urlencoded({ extended: true }))
router.use(methodOverride(function(req, res){
      if (req.body && typeof req.body === 'object' && '_method' in req.body) {
        // look in urlencoded POST bodies and delete it
        var method = req.body._method
        delete req.body._method
        return method
      }
}));

router.get('/', async (req,res)=>{
    res.render('login/index');
});
router.post('/',async (req,res)=>
{
    try{
        const {username, password}=req.body;
    const user=await User.findOne({username:username});
    if(!user)
    {
        return res.status(404).send("Korisnik nije pronađen");
    }
    const passwordEqual= await bcrypt.compare(password,user.password);
    if(!passwordEqual)
    {
        res.status(404).send("Neispravna lozinka");
    }
    req.session.uid=user;
    res.format(
        {
            html:function()
            {
                res.redirect('/projects');
            }
        }
    )

    }
    catch(error)
    {
        console.error(error);
        res.status(500).send("Došlo je do pogreške prilikom prijave" +error.message);
    }
    
    
});
module.exports = router;
