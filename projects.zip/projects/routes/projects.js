var express = require('express');
var router = express.Router();
    mongoose = require('mongoose'), //mongo connection
    bodyParser = require('body-parser'), //parses information from POST
    methodOverride = require('method-override'); //used to manipulate POST

const Project=require('../models/project');
const User= require('../models/users');
//Any requests to this controller must pass through this 'use' function
//Copy and pasted from method-override
router.use(bodyParser.urlencoded({ extended: true }))
router.use(methodOverride(function(req, res){
      if (req.body && typeof req.body === 'object' && '_method' in req.body) {
        // look in urlencoded POST bodies and delete it
        var method = req.body._method
        delete req.body._method
        return method
      }
}))
// Glavna stranica
router.get('/', function(req, res) {
  res.render('index', { title: 'Dobrodošli' });
});
//Dohvacanje svih projekata
router.get('/projects', async(req,res) =>
{
  if(CheckLogin(req,res)) return;
  try
  {
    const projects = await Project.find();
    res.render('projects/index',{title:"Projekti",projects});
  }
  catch(err)
  {
    res.status(500).send(err.message);
  }
});
//Ruta za stvaranje novog projekta
router.get('/project/new',async (req,res)=>
{
  if(CheckLogin(req,res)) return;
  res.render('projects/new', {title: 'Novi projekt'});
})

router.get('/my',async(req,res)=>
{
  if(CheckLogin(req,res))return;

  try
  {
    const userId=req.session.uid.toString();
    const user = await mongoose.model('User').findById(userId);
    const leaderProject= await mongoose.model('Project').find({author:userId});
    res.format(
      {
        html:function()
        {
          res.render('project/my',{
            title:"My projects",
            "leaderProjects": leaderProject, 
          });
        }
      }
    )
  }
  catch(error)
  {
    console.error(error);
    res.status(500).send("Greška");
  }
})

router.post('/project',async(req,res)=>
{
  if(CheckLogin(req,res)) return;
  const { name, description, price, tasks,teamMembers, jobDone, startDate, endDate, archived}=req.body;
  const authorID=req.session.uid;
  const archivedN= req.body.archived === 'on' ? true : false;
  try
  { const author=await User.findById(authorID);
    const newProject= new Project(
    {
      name,
      description,
      price,
      tasks,
      teamMembers,
      jobDone,
      startDate,
      endDate,
      archived:archivedN,
      author:author.username
    }
  );
    const savedProject = await newProject.save();
    res.format({
    html: function(){
        res.location('projects');
        res.redirect("/projects");
    },
    json: function(){
        res.json(savedProject);
    }
    });
  }
  catch(err)
  {
    res.status(400).send(err.message);
  }
});




//Azuriranja projekta
router.get('/project/:id/edit',async(req,res)=>
{
  
  if(CheckLogin(req,res)) return;
  const ProjectID=req.params.id;
  try
  {
    const project=await Project.findById(ProjectID);
    if(!project)
    {
      return res.status(404).send("Projekt nije pronađen");
    }
    res.render('projects/edit',{project});
  }
  catch(err)
  {
    res.status(500).send('Greška:${err.message}');
  }
});

router.put('/project/:id', async (req, res) => {
  if (CheckLogin(req, res)) return;
  const projectId = req.params.id;
  try {
      let updateFields = req.body; // Svi podaci koji su poslani u zahtjevu

      // Provjera i obrada arhiviranosti projekta
      if (typeof req.body.archived !== 'undefined') {
          updateFields.archived = req.body.archived === 'on'; // Postavljanje na true ako je checkbox označen
      }

      const updateProject = await Project.findByIdAndUpdate(projectId,
          updateFields, // Ažuriramo samo polja koja su poslana u zahtjevu
          { new: true, runValidators: true }
      );

      if (!updateProject) {
          return res.status(404).send("Projekt nije pronađen");
      }

      res.format({
          html: function () {
              res.redirect("/projects");
          },
          json: function () {
              res.json(updateProject); // Vraćamo ažurirani projekt
          }
      });
  } catch (error) {
      res.status(500).send(`Greška: ${error.message}`);
  }
});


//Prikaz detalja projekta
router.get('/project/:id/show',async(req,res)=>
{
  if(CheckLogin(req,res)) return;
  const ProjectID=req.params.id;
  try
  {
    const project=await Project.findById(ProjectID);
    if(!project)
    {
      return res.status(404).send("Projekt nije pronađen");
    }
    res.render('projects/show',{project});
  }
  catch(err)
  {
    res.status(500).send('Greška:${err.message}');
  }
});

//Brisanje projekta
router.delete('/projects/:id',async(req,res)=>
{
  if(CheckLogin(req,res)) return;
  const projectId=req.params.id;

  if(!mongoose.Types.ObjectId.isValid(projectId))
  {
    return res.status(400).send("Nevažeći ID");
  }
  try
  {
    const deletedProject= await Project.findByIdAndDelete(req.params.id);
    if(!deletedProject)
    {
      return res.status(404).send('Project not found');
    }
    res.format({
    html: function(){
        res.redirect("/projects");
    },
    json: function(){
        res.json(savedProject);
    }
    });
  }
  catch(error)
  {
    res.status(500).send(error.message);
  }
});

function CheckLogin(req,res)
{
  if(!req.session.uid)
  {
    res.redirect('/login');
    return true;
  }
  return false;
}
module.exports = router;
