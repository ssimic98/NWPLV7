var express = require('express');
var router = express.Router();
    mongoose = require('mongoose'), //mongo connection
    bodyParser = require('body-parser'), //parses information from POST
    methodOverride = require('method-override'); //used to manipulate POST
    bcrypt= require('bcrypt');
const User=require('../models/users');
//Any requests to this controller must pass through this 'use' function
//Copy and pasted from method-override
router.use(bodyParser.urlencoded({ extended: true }))
router.use(methodOverride(function(req, res){
      if (req.body && typeof req.body === 'object' && '_method' in req.body) {
        // look in urlencoded POST bodies and delete it
        var method = req.body._method
        delete req.body._method
        return method
      }
}));

router.get('/', async (req,res)=>{
    res.render('register/index');
});
router.post('/', async (req,res)=>
{
    try
    {
        const{username,email,password,confirmPassword}=req.body;
        console.log(req.body);
        const existingUser = await User.findOne({ $or: [{ username }, { email }] });
        if(password !== confirmPassword)
            {
                return res.status(400).send("Lozinke se ne podudaraju");
            }
        if(existingUser)
        {
            return res.status(400).send('Korisnicko ime ili mail već postoji ');
        }
        
        const hashedPassword= await bcrypt.hash(password,10);
        const newUser = new User(
            {
                username, email, password:hashedPassword
            }
        );
        await newUser.save();
        res.format(
            {
                html:function()
                {
                    res.redirect('/login');
                }
            }
        )
    }
    catch(error)
    {
        console.error(error);
        res.status(500).send("Došlo je do pogreške");
    }
});
module.exports = router;
